Definition = function (word, partOfSpeech, definition, synonym) {
    this.word = word;
    this.partOfSpeech = partOfSpeech;
    this.definition = definition;
    this.synonym = synonym;
};

Definition.prototype.display = function() {
    //decide how to display
};
