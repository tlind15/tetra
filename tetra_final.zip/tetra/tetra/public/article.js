//Create Article object
Article = function(title, article, link) {
    this.title = title;
    this.article = article;
    this.link = link;
};
